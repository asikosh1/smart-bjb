// For Firebase JS SDK v7.20.0 and later, measurementId is optional
export const firebaseConfig = {
  apiKey: "AIzaSyDv2qwLvW7qUQtC_oBiF1--BATnkwrsdfTI",
  authDomain: "smart-bjb.firebaseapp.com",
  projectId: "smart-bjb",
  storageBucket: "smart-bjb.firebasestorage.app",
  messagingSenderId: "763922625099",
  appId: "1:763922625099:web:c90c2b7019fe44aa7d93ce",
  measurementId: "G-Y2KNMJTVPR"
};