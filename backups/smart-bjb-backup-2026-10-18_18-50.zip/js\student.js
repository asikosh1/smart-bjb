// student.html — student login/register via Firestore + anonymous Firebase auth for writes + test + leave detection
import { ensureAnonAuth, loginStudent, registerStudent, getStudentSession, setStudentSession, clearStudentSession } from "./auth.js";
import { db } from "./firebase.js";
import {
  doc,
  getDoc,
  collection,
  addDoc,
  updateDoc,
  serverTimestamp,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  qp,
  esc,
  formatDurationSec,
  formatTimer,
  gradeAnswers,
  getLevel,
  getLevelDescription,
  getLevelBadgeClass,
  totalPoints,
  showToast,
} from "./utils.js";

const assessmentId = qp("a");
const elLoading = document.getElementById("state-loading");
const elError = document.getElementById("state-error");
const elErrorText = document.getElementById("error-text");
const elStepAuth = document.getElementById("step-auth");
const elStepInfo = document.getElementById("step-info");
const elStepTest = document.getElementById("step-test");
const elStepResult = document.getElementById("step-result");

function showError(msg) {
  if (elLoading) elLoading.classList.add("hidden");
  if (elError) elError.classList.remove("hidden");
  if (elErrorText) elErrorText.textContent = msg;
  [elStepAuth, elStepInfo, elStepTest, elStepResult].forEach((e) => e && e.classList.add("hidden"));
}

if (!assessmentId) {
  showError("Сілтеме қате: БЖБ идентификаторы табылмады (?a=...). Мұғалімнен дұрыс сілтемені сұраңыз.");
  throw new Error("missing a param");
}

// Ensure anonymous auth for Firestore access (needed to query students + read assessment)
let currentUser;
try {
  currentUser = await ensureAnonAuth();
} catch (e) {
  showError("Авторизация қатесі: " + (e.message || e.code) + " — Firebase Console → Authentication → Anonymous қосылғанын тексеріңіз.");
  throw e;
}

// Load assessment
let assessment;
try {
  const snap = await getDoc(doc(db, "assessments", assessmentId));
  if (!snap.exists()) {
    showError("БЖБ табылмады. Сілтеме ескірген болуы мүмкін.");
    throw new Error("not found");
  }
  assessment = { id: snap.id, ...snap.data() };
  if (assessment.status !== "published") {
    showError("Бұл БЖБ әлі жарияланбаған. Мұғалім жариялаған соң қайта кіріңіз.");
    throw new Error("not published");
  }
} catch (e) {
  if (elError.classList.contains("hidden")) {
    showError("Жүктеу қатесі: " + (e.message || e.code));
  }
  throw e;
}

if (elLoading) elLoading.classList.add("hidden");

// ----- Auth UI -----
const authLogged = document.getElementById("auth-logged");
const authLoggedName = document.getElementById("auth-logged-name");
const authLoggedLogin = document.getElementById("auth-logged-login");
const btnContinueLogged = document.getElementById("btn-continue-logged");
const btnLogoutStudent = document.getElementById("btn-logout-student");
const authForms = document.getElementById("auth-forms");
const tabLogin = document.querySelector('#step-auth [data-tab="login"]');
const tabReg = document.querySelector('#step-auth [data-tab="register"]');
const formLogin = document.getElementById("form-login");
const formRegister = document.getElementById("form-register");
const loginErr = document.getElementById("login-error");
const regErr = document.getElementById("reg-error");
const regOk = document.getElementById("reg-ok");
const linkStudentAuth = document.getElementById("link-student-auth");
if (linkStudentAuth) linkStudentAuth.href = `student-auth.html?a=${encodeURIComponent(assessmentId)}`;

let studentSession = getStudentSession(); // {id, name, login, ...}
let submissionId = null;
let submissionData = null;
let studentName = "";
let pendingAnswers = {};
let timerInterval = null;
let remainingSec = assessment.durationSec || 600;
let leaveCount = 0;
let totalAwayMs = 0;
let awayStart = null;
let lastEventTime = 0;
let lastEventType = null;

// LS keys per student+assessment
function lsSubKey() {
  const sid = studentSession ? studentSession.id : currentUser.uid;
  return `smart-bjb:sub:${assessmentId}:${sid}`;
}
function lsAnswersKey(subId) {
  return `smart-bjb:answers:${assessmentId}:${subId}`;
}

function showStepAuth() {
  if (elStepAuth) elStepAuth.classList.remove("hidden");
  if (elStepInfo) elStepInfo.classList.add("hidden");
  if (elStepTest) elStepTest.classList.add("hidden");
  if (elStepResult) elStepResult.classList.add("hidden");
  updateAuthUI();
}

function updateAuthUI() {
  studentSession = getStudentSession();
  const logged = !!(studentSession && studentSession.login);
  if (authLogged) authLogged.classList.toggle("hidden", !logged);
  if (authForms) authForms.classList.toggle("hidden", logged);
  if (logged && authLoggedName) authLoggedName.textContent = studentSession.name || studentSession.login;
  if (logged && authLoggedLogin) authLoggedLogin.textContent = "@" + studentSession.login;
}

function switchTab(which) {
  const isLogin = which === "login";
  if (tabLogin) { tabLogin.classList.toggle("active", isLogin); tabLogin.setAttribute("aria-selected", String(isLogin)); }
  if (tabReg) { tabReg.classList.toggle("active", !isLogin); tabReg.setAttribute("aria-selected", String(!isLogin)); }
  if (formLogin) formLogin.classList.toggle("hidden", !isLogin);
  if (formRegister) formRegister.classList.toggle("hidden", isLogin);
  if (loginErr) loginErr.textContent = "";
  if (regErr) regErr.textContent = "";
  if (regOk) regOk.textContent = "";
}
tabLogin?.addEventListener("click", () => switchTab("login"));
tabReg?.addEventListener("click", () => switchTab("register"));

btnLogoutStudent?.addEventListener("click", () => {
  clearStudentSession();
  studentSession = null;
  submissionId = null;
  submissionData = null;
  updateAuthUI();
  switchTab("login");
});

// If already logged, show "Continue" to skip login
btnContinueLogged?.addEventListener("click", async () => {
  if (!studentSession) return;
  await afterAuth();
});

// Login
formLogin?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (loginErr) loginErr.textContent = "";
  const login = document.getElementById("login-login").value.trim();
  const pass = document.getElementById("login-pass").value;
  if (!login || !pass) { if (loginErr) loginErr.textContent = "Логин мен парольді толтырыңыз"; return; }
  try {
    if (loginErr) loginErr.textContent = "Тексерілуде...";
    const stu = await loginStudent(login, pass);
    if (!stu) { if (loginErr) loginErr.textContent = "Логин немесе пароль қате"; return; }
    setStudentSession({ id: stu.id, name: stu.name, login: stu.login, password: stu.password, teacherUid: stu.teacherUid || null });
    studentSession = getStudentSession();
    if (loginErr) loginErr.textContent = "";
    showToast("Сәтті кірдіңіз");
    await afterAuth();
  } catch (err) {
    if (loginErr) loginErr.textContent = err.message || String(err);
  }
});

// Register (via link — teacherUid from assessment owner if available)
formRegister?.addEventListener("submit", async (e) => {
  e.preventDefault();
  if (regErr) regErr.textContent = "";
  if (regOk) regOk.textContent = "";
  const name = document.getElementById("reg-name").value.trim();
  const login = document.getElementById("reg-login").value.trim();
  const pass = document.getElementById("reg-pass").value;
  const pass2 = document.getElementById("reg-pass2").value;
  if (!name || !login || !pass) { if (regErr) regErr.textContent = "Барлық өрісті толтырыңыз"; return; }
  if (!/^[a-zA-Z0-9_.-]{3,32}$/.test(login)) { if (regErr) regErr.textContent = "Логин: 3–32 таңба, тек латын әріп/сан/_ . -"; return; }
  if (pass.length < 4) { if (regErr) regErr.textContent = "Пароль кемінде 4 таңба"; return; }
  if (pass !== pass2) { if (regErr) regErr.textContent = "Парольдер сәйкес емес"; return; }
  try {
    if (regErr) regErr.textContent = "Тіркелуде...";
    // link to this assessment's teacher
    const teacherUid = assessment.ownerUid || null;
    const stu = await registerStudent({ name, login, password: pass, teacherUid });
    setStudentSession({ id: stu.id, name: stu.name, login: stu.login, password: stu.password, teacherUid: stu.teacherUid || null });
    studentSession = getStudentSession();
    if (regOk) regOk.textContent = "Тіркелдіңіз!";
    if (regErr) regErr.textContent = "";
    showToast("Тіркелдіңіз");
    await afterAuth();
  } catch (err) {
    if (regErr) regErr.textContent = err.message || String(err);
  }
});

// After auth -> check existing submission, show info card
async function afterAuth() {
  if (!studentSession) { showStepAuth(); return; }
  studentName = studentSession.name || studentSession.login;
  submissionId = localStorage.getItem(lsSubKey()) || null;
  submissionData = null;
  pendingAnswers = {};

  // Check existing submission for this student+assessment
  if (submissionId) {
    try {
      const s = await getDoc(doc(db, "assessments", assessmentId, "submissions", submissionId));
      if (s.exists()) {
        const d = s.data();
        // Verify belongs to this student (by studentId or legacy anonymous uid)
        const belongsToMe = (d.studentId === studentSession.id) || (d.studentUid === currentUser.uid) || (d.studentUid === studentSession.id);
        if (d.status === "submitted" && belongsToMe) {
          showResultFromData(d, assessment.questions || []);
          return;
        }
        if (d.status === "in_progress" && belongsToMe) {
          submissionData = { id: s.id, ...d };
          leaveCount = d.leaveCount || 0;
          totalAwayMs = d.totalAwayMs || 0;
          try {
            const localAns = JSON.parse(localStorage.getItem(lsAnswersKey(submissionId)) || "null");
            if (localAns) pendingAnswers = localAns;
            else if (d.answers) pendingAnswers = { ...d.answers };
          } catch {}
        } else if (!belongsToMe) {
          // Different student, ignore old submission
          submissionId = null;
          submissionData = null;
        }
      }
    } catch {}
  }

  showInfoCard();
}

function showInfoCard() {
  if (elStepAuth) elStepAuth.classList.add("hidden");
  if (elStepInfo) elStepInfo.classList.remove("hidden");
  const tp = assessment.totalPoints ?? totalPoints(assessment.questions || []);
  const elTopic = document.getElementById("info-topic");
  const elTeacher = document.getElementById("info-teacher");
  const elSubject = document.getElementById("info-subject");
  const elTopic2 = document.getElementById("info-topic2");
  const elCount = document.getElementById("info-count");
  const elPoints = document.getElementById("info-points");
  const elDur = document.getElementById("info-duration");
  if (elTopic) elTopic.textContent = assessment.topic || "—";
  if (elTeacher) elTeacher.textContent = assessment.teacherName || "—";
  if (elSubject) elSubject.textContent = assessment.subject || "—";
  if (elTopic2) elTopic2.textContent = assessment.topic || "—";
  if (elCount) elCount.textContent = String((assessment.questions || []).length);
  if (elPoints) elPoints.textContent = String(tp);
  if (elDur) elDur.textContent = formatDurationSec(assessment.durationSec);

  const sNameEl = document.getElementById("info-student-name");
  const sLoginEl = document.getElementById("info-student-login");
  if (sNameEl) sNameEl.textContent = studentSession ? (studentSession.name || "—") : "—";
  if (sLoginEl) sLoginEl.textContent = studentSession ? "(@" + studentSession.login + ")" : "";

  const btnStart = document.getElementById("btn-start");
  if (btnStart) btnStart.textContent = (submissionData && submissionData.status === "in_progress") ? "Жалғастыру" : "Бастау";
}

document.getElementById("btn-change-student")?.addEventListener("click", () => {
  clearStudentSession();
  studentSession = null;
  submissionId = null;
  submissionData = null;
  if (elStepInfo) elStepInfo.classList.add("hidden");
  showStepAuth();
});

// Initial: if already logged, go to afterAuth; else show auth
if (studentSession && studentSession.login) {
  // verify session still valid (optional)
  (async () => {
    try {
      // quick check: try to login with stored creds (if teacher changed password, session invalid)
      const fresh = await loginStudent(studentSession.login, studentSession.password);
      if (!fresh) {
        // keep session but warn? Or clear?
        // Keep but will fail on test start? Better clear
        clearStudentSession();
        studentSession = null;
        showStepAuth();
        return;
      }
      // refresh name if changed
      if (fresh.name !== studentSession.name) {
        setStudentSession({ ...studentSession, name: fresh.name });
        studentSession = getStudentSession();
      }
    } catch {}
    await afterAuth();
  })();
} else {
  showStepAuth();
}

// ----- Test flow -----
const btnStart = document.getElementById("btn-start");
btnStart?.addEventListener("click", async () => {
  if (!studentSession) {
    showToast("Алдымен кіріңіз");
    showStepAuth();
    return;
  }
  btnStart.disabled = true;
  btnStart.textContent = "Жүктелуде...";
  try {
    if (!submissionId || (submissionData && submissionData.status === "submitted")) {
      const ref = await addDoc(collection(db, "assessments", assessmentId, "submissions"), {
        studentId: studentSession.id,
        studentUid: studentSession.id, // keep for rules compat
        studentName: studentSession.name || studentSession.login,
        studentLogin: studentSession.login,
        answers: {},
        score: 0,
        percent: 0,
        level: "",
        status: "in_progress",
        startedAt: serverTimestamp(),
        submittedAt: null,
        leaveCount: 0,
        totalAwayMs: 0,
        assessmentType: assessment.type,
      });
      submissionId = ref.id;
      localStorage.setItem(lsSubKey(), submissionId);
      leaveCount = 0;
      totalAwayMs = 0;
    }
    try {
      const saved = JSON.parse(localStorage.getItem(lsAnswersKey(submissionId)) || "null");
      if (saved && typeof saved === "object") pendingAnswers = saved;
      else if (submissionData?.answers) pendingAnswers = { ...submissionData.answers };
    } catch {}
    startTest();
  } catch (e) {
    console.error(e);
    showToast("Бастау қатесі: " + (e.message || e.code));
    btnStart.disabled = false;
    btnStart.textContent = "Бастау";
  }
});

function startTest() {
  if (elStepInfo) elStepInfo.classList.add("hidden");
  if (elStepTest) elStepTest.classList.remove("hidden");
  remainingSec = assessment.durationSec || 600;
  const savedRemaining = localStorage.getItem(`smart-bjb:remaining:${assessmentId}:${submissionId}`);
  if (savedRemaining) {
    const v = parseInt(savedRemaining, 10);
    if (!isNaN(v) && v > 0 && v < remainingSec) remainingSec = v;
  }
  renderQuestions();
  startTimer();
  attachLeaveListeners();
  const firstInput = document.querySelector("#questions input, #questions textarea");
  if (firstInput) firstInput.focus();
}

function renderQuestions() {
  const container = document.getElementById("questions");
  if (!container) return;
  const qs = assessment.questions || [];
  container.innerHTML = qs
    .map((q, idx) => {
      const val = pendingAnswers[q.id];
      let inputHtml = "";
      if (q.type === "single") {
        inputHtml = `
          <div class="q-options" role="radiogroup" aria-label="Сұрақ ${idx + 1}">
            ${(q.options || [])
              .map(
                (opt, oi) => `
              <label class="flex gap8" style="align-items:center;padding:10px;border:1px solid var(--border);border-radius:10px;cursor:pointer;background:${String(val) === String(oi) ? "var(--row-bg)" : "var(--card)"}">
                <input type="radio" name="q-${esc(q.id)}" value="${oi}" ${String(val) === String(oi) ? "checked" : ""} />
                <span>${esc(opt)}</span>
              </label>`
              )
              .join("")}
          </div>`;
      } else if (q.type === "short") {
        inputHtml = `<input type="text" class="input" data-qid="${esc(q.id)}" value="${esc(val || "")}" placeholder="Жауабыңызды жазыңыз" />`;
      } else {
        inputHtml = `<textarea class="textarea" data-qid="${esc(q.id)}" placeholder="Жауабыңызды жазыңыз...">${esc(val || "")}</textarea>`;
      }
      return `
      <div class="q-card">
        <div class="flex between gap8">
          <span class="small muted">#${idx + 1} · ${q.points} балл</span>
          <span class="pill" style="font-size:11px">${q.type === "single" ? "Бір жауапты" : q.type === "short" ? "Қысқа жауап" : "Ашық"}</span>
        </div>
        <p style="font-weight:600;margin:10px 0 12px">${esc(q.text)}</p>
        ${inputHtml}
      </div>`;
    })
    .join("");

  container.querySelectorAll("input[type='radio']").forEach((el) => {
    el.addEventListener("change", () => {
      const qid = el.name.replace("q-", "");
      pendingAnswers[qid] = el.value;
      persistAnswers();
    });
  });
  container.querySelectorAll("input[data-qid], textarea[data-qid]").forEach((el) => {
    el.addEventListener("input", () => {
      pendingAnswers[el.dataset.qid] = el.value;
      persistAnswers();
    });
  });
}

function persistAnswers() {
  if (!submissionId) return;
  try {
    localStorage.setItem(lsAnswersKey(submissionId), JSON.stringify(pendingAnswers));
    debouncedFirestoreSync();
  } catch {}
}

const debouncedFirestoreSync = (() => {
  let t = null;
  return () => {
    clearTimeout(t);
    t = setTimeout(async () => {
      if (!submissionId) return;
      try {
        await updateDoc(doc(db, "assessments", assessmentId, "submissions", submissionId), {
          answers: pendingAnswers,
        });
      } catch (_) {}
    }, 800);
  };
})();

function startTimer() {
  const valEl = document.getElementById("timer-value");
  const timerEl = document.getElementById("timer");
  function tick() {
    if (valEl) valEl.textContent = formatTimer(remainingSec);
    if (timerEl) timerEl.classList.toggle("warn", remainingSec <= 60);
    try {
      localStorage.setItem(`smart-bjb:remaining:${assessmentId}:${submissionId}`, String(remainingSec));
    } catch {}
    if (remainingSec <= 0) {
      clearInterval(timerInterval);
      showToast("Уақыт бітті — жауаптар жіберілуде");
      doSubmit(true);
      return;
    }
    remainingSec -= 1;
  }
  tick();
  timerInterval = setInterval(tick, 1000);
}

// Leave detection
function attachLeaveListeners() {
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) handleLeave("visibility");
    else handleReturn("visibility");
  });
  window.addEventListener("blur", () => handleLeave("blur"));
  window.addEventListener("focus", () => handleReturn("focus"));
}

async function handleLeave(source) {
  if (!submissionId) return;
  const now = Date.now();
  if (now - lastEventTime < 1000) return;
  if (lastEventType === "left") return;
  lastEventType = "left";
  lastEventTime = now;
  awayStart = now;
  leaveCount += 1;
  const sName = studentSession ? (studentSession.name || studentSession.login) : "Оқушы";
  try {
    await addDoc(collection(db, "assessments", assessmentId, "events"), {
      submissionId,
      studentName: sName,
      studentLogin: studentSession ? studentSession.login : "",
      type: "left",
      at: serverTimestamp(),
      source,
    });
  } catch (e) { console.warn("event write failed", e); }
  try {
    await updateDoc(doc(db, "assessments", assessmentId, "submissions", submissionId), { leaveCount, totalAwayMs });
  } catch (e) { console.warn("submission leave update failed", e); }
}

async function handleReturn(source) {
  if (!submissionId) return;
  const now = Date.now();
  if (now - lastEventTime < 1000) return;
  if (lastEventType !== "left") return;
  lastEventType = "returned";
  lastEventTime = now;
  if (awayStart != null) {
    totalAwayMs += now - awayStart;
    awayStart = null;
  }
  const sName = studentSession ? (studentSession.name || studentSession.login) : "Оқушы";
  try {
    await addDoc(collection(db, "assessments", assessmentId, "events"), {
      submissionId,
      studentName: sName,
      studentLogin: studentSession ? studentSession.login : "",
      type: "returned",
      at: serverTimestamp(),
      source,
    });
  } catch (e) { console.warn("event write failed", e); }
  try {
    await updateDoc(doc(db, "assessments", assessmentId, "submissions", submissionId), { totalAwayMs });
  } catch (e) { console.warn("submission return update failed", e); }
}

// Submit
let submitting = false;
document.getElementById("btn-submit")?.addEventListener("click", () => doSubmit(false));

async function doSubmit(isAuto) {
  if (submitting) return;
  if (!submissionId) {
    showToast("Қате: submission табылмады");
    return;
  }
  if (!isAuto && !confirm("Жауаптарды жіберу керек пе? Кейін өзгерту мүмкін емес.")) return;

  submitting = true;
  const btn = document.getElementById("btn-submit");
  if (btn) { btn.disabled = true; btn.textContent = "Жіберілуде..."; }
  clearInterval(timerInterval);

  if (awayStart != null) {
    totalAwayMs += Date.now() - awayStart;
    awayStart = null;
  }

  const qs = assessment.questions || [];
  const tp = assessment.totalPoints ?? totalPoints(qs);
  const grading = gradeAnswers(qs, pendingAnswers);
  const score = grading.score;
  const percent = tp ? Math.round((score / tp) * 100) : 0;
  const level = getLevel(percent);

  try {
    await updateDoc(doc(db, "assessments", assessmentId, "submissions", submissionId), {
      answers: pendingAnswers,
      score,
      percent,
      level,
      status: "submitted",
      submittedAt: serverTimestamp(),
      leaveCount,
      totalAwayMs,
      totalPoints: tp,
      gradedPoints: grading.totalGraded,
      pendingOpen: grading.pendingOpen,
    });
    try { localStorage.removeItem(`smart-bjb:remaining:${assessmentId}:${submissionId}`); } catch {}
    showResultFromData({ score, percent, level, answers: pendingAnswers, pendingOpen: grading.pendingOpen }, qs);
  } catch (e) {
    console.error(e);
    showToast("Жіберу қатесі: " + (e.message || e.code));
    if (btn) { btn.disabled = false; btn.textContent = "Жіберу"; }
    submitting = false;
  }
}

function showResultFromData(data, qs) {
  if (elStepTest) elStepTest.classList.add("hidden");
  if (elStepAuth) elStepAuth.classList.add("hidden");
  if (elStepInfo) elStepInfo.classList.add("hidden");
  if (elLoading) elLoading.classList.add("hidden");
  if (elStepResult) elStepResult.classList.remove("hidden");

  const scoreEl = document.getElementById("result-score");
  const percentEl = document.getElementById("result-percent");
  const badgeEl = document.getElementById("result-badge");
  const descEl = document.getElementById("result-desc");
  const breakdownEl = document.getElementById("result-breakdown");

  const tp = assessment.totalPoints ?? totalPoints(qs);
  const score = data.score ?? 0;
  const percent = data.percent ?? (tp ? Math.round((score / tp) * 100) : 0);
  const level = data.level || getLevel(percent);

  if (scoreEl) scoreEl.textContent = `${score} / ${tp}`;
  if (percentEl) percentEl.textContent = `${percent}%`;
  if (badgeEl) badgeEl.innerHTML = `<span class="badge ${getLevelBadgeClass(level)}" style="font-size:15px;padding:6px 14px">${esc(level)}</span>`;
  if (descEl) descEl.textContent = getLevelDescription(level);

  if (breakdownEl) {
    if (data.pendingOpen > 0) {
      breakdownEl.innerHTML = `<p class="small muted" style="background:var(--row-bg);padding:12px;border-radius:10px">Ашық сұрақтар мұғалім тексерген соң қорытынды балл жаңарады.</p>`;
    } else {
      breakdownEl.innerHTML = "";
    }
    const rows = (qs || [])
      .map((q, idx) => {
        if (q.type === "open") return "";
        const given = data.answers ? data.answers[q.id] : pendingAnswers[q.id];
        let correct = false;
        if (q.type === "single") correct = String(given) === String(q.correct);
        else if (q.type === "short") correct = String(given || "").trim().toLowerCase() === String(q.correct).trim().toLowerCase();
        return `<div style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid var(--border)">
          <span>#${idx + 1} ${esc(q.text.slice(0, 60))}${q.text.length > 60 ? "…" : ""}</span>
          <span style="font-weight:700;color:${correct ? "var(--accent)" : "var(--danger)"}">${correct ? "✓" : "✕"} ${correct ? q.points : 0}/${q.points}</span>
        </div>`;
      })
      .join("");
    if (rows) breakdownEl.innerHTML += `<div style="margin-top:12px">${rows}</div>`;
  }
}
