// result.html — live stats, table, hardest questions, open grading, events + notify
import { requireTeacher, doSignOut } from "./auth.js";
import { db } from "./firebase.js";
import {
  doc,
  getDoc,
  collection,
  query,
  orderBy,
  onSnapshot,
  updateDoc,
} from "https://www.gstatic.com/firebasejs/10.12.2/firebase-firestore.js";
import {
  qp,
  esc,
  formatDurationSec,
  formatDate,
  getLevel,
  getLevelBadgeClass,
  totalPoints,
  showToast,
  gradeAnswers,
} from "./utils.js";
import {
  initVoiceToggle,
  setVoiceEnabled,
  isVoiceEnabled,
  requestNotificationPermission,
  notifyLeave,
} from "./notify.js";

const assessmentId = qp("a");
const elLoading = document.getElementById("state-loading");
const elError = document.getElementById("state-error");
const elErrorText = document.getElementById("error-text");
const elContent = document.getElementById("content");

function showError(msg) {
  if (elLoading) elLoading.classList.add("hidden");
  if (elContent) elContent.classList.add("hidden");
  if (elError) elError.classList.remove("hidden");
  if (elErrorText) elErrorText.textContent = msg;
}

if (!assessmentId) {
  showError("Сілтеме қате: ?a= параметрі жоқ.");
  throw new Error("missing a");
}

// Require teacher (Google) — result is teacher-only
const user = await requireTeacher("index.html");
if (!user) throw new Error("not authed");

document.getElementById("btn-logout")?.classList.remove("hidden");
document.getElementById("btn-logout")?.addEventListener("click", () => doSignOut().then(() => (location.href = "index.html")));

// Load assessment
let assessment;
try {
  const snap = await getDoc(doc(db, "assessments", assessmentId));
  if (!snap.exists()) throw new Error("БЖБ табылмады");
  assessment = { id: snap.id, ...snap.data() };
  if (assessment.ownerUid !== user.uid) {
    showError("Бұл БЖБ сізге тиесілі емес. Тек иесі нәтижені көре алады.");
    throw new Error("not owner");
  }
} catch (e) {
  if (elError.classList.contains("hidden")) showError(e.message || String(e));
  throw e;
}

// Show meta
if (elLoading) elLoading.classList.add("hidden");
if (elContent) elContent.classList.remove("hidden");
const rTopic = document.getElementById("r-topic");
const rMeta = document.getElementById("r-meta");
if (rTopic) rTopic.textContent = assessment.topic || "—";
if (rMeta) {
  const tp = assessment.totalPoints ?? totalPoints(assessment.questions || []);
  rMeta.textContent = `${assessment.type} · ${assessment.subject || "—"} · ${formatDurationSec(assessment.durationSec)} · ${tp} балл · ${formatDate(assessment.createdAt)}`;
}

// Link copy
document.getElementById("btn-copy-link")?.addEventListener("click", async () => {
  const url = `${location.origin}/student.html?a=${assessmentId}`;
  try {
    await navigator.clipboard.writeText(url);
    showToast("Сілтеме көшірілді");
  } catch {
    prompt("Сілтеме:", url);
  }
});

// Voice toggle + notify permission
const toggleVoice = document.getElementById("toggle-voice");
const btnNotify = document.getElementById("btn-enable-notify");
const initialVoice = initVoiceToggle();
if (toggleVoice) {
  toggleVoice.checked = initialVoice;
  toggleVoice.addEventListener("change", () => {
    setVoiceEnabled(toggleVoice.checked);
    showToast(toggleVoice.checked ? "Дауыс қосылды" : "Дауыс өшірілді");
  });
  // Enable voice only after first user gesture (autoplay policy)
  // So we trigger warm-up on toggle click; notify.js handles it
}
if (btnNotify) {
  // Reflect current permission
  if (typeof Notification !== "undefined" && Notification.permission === "granted") {
    btnNotify.textContent = "Хабарлама қосулы ✓";
    btnNotify.disabled = true;
  }
  btnNotify.addEventListener("click", async () => {
    const ok = await requestNotificationPermission();
    if (ok) {
      showToast("Хабарлама қосылды");
      btnNotify.textContent = "Хабарлама қосулы ✓";
      btnNotify.disabled = true;
      // Unlock voice as well on this gesture
      if (toggleVoice && !toggleVoice.checked) {
        // don't auto-enable, just warm up
        setVoiceEnabled(true);
        toggleVoice.checked = true;
      } else if (toggleVoice && toggleVoice.checked) {
        setVoiceEnabled(true);
      }
    } else {
      showToast("Хабарламаға рұқсат берілмеді");
    }
  });
  // Also enable voice on any click on page (for autoplay policy)
  document.addEventListener("click", () => {
    if (toggleVoice && toggleVoice.checked) setVoiceEnabled(true);
  }, { once: true });
}

// Data state
let submissions = []; // [{id, ...data}]
let events = [];
let initialEventsLoaded = false;
let seenEventIds = new Set();

// Submissions listener
const subCol = collection(db, "assessments", assessmentId, "submissions");
const subUnsub = onSnapshot(subCol, (snap) => {
  submissions = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  renderStats();
  renderTable();
  renderHardQuestions();
  renderOpenGrading();
}, (err) => {
  console.error("submissions snapshot error", err);
  showToast("Дерек жүктеу қатесі: " + (err.message || err.code));
});

// Events listener
const evCol = collection(db, "assessments", assessmentId, "events");
let evQuery;
try {
  evQuery = query(evCol, orderBy("at", "asc"));
} catch {
  evQuery = evCol;
}
const evUnsub = onSnapshot(evQuery, (snap) => {
  const docs = snap.docs.map((d) => ({ id: d.id, ...d.data() }));
  // Detect new "left" events after initial load
  if (!initialEventsLoaded) {
    events = docs;
    docs.forEach((e) => seenEventIds.add(e.id));
    initialEventsLoaded = true;
    renderEvents();
    // Also update leave counts from submissions (source of truth)
    return;
  }
  for (const e of docs) {
    if (seenEventIds.has(e.id)) continue;
    seenEventIds.add(e.id);
    events.push(e);
    if (e.type === "left") {
      const name = e.studentName || "Оқушы";
      notifyLeave(name);
    }
  }
  // Keep sorted by at
  events.sort((a, b) => {
    const av = a.at?.toMillis?.() || 0;
    const bv = b.at?.toMillis?.() || 0;
    return av - bv;
  });
  renderEvents();
  // Refresh table counts (events also update submissions.leaveCount, but show immediate feedback)
}, (err) => {
  console.error("events snapshot error", err);
});

// Render functions
function renderStats() {
  const total = submissions.length;
  const submitted = submissions.filter((s) => s.status === "submitted").length;
  const scores = submissions.filter((s) => s.status === "submitted").map((s) => Number(s.score) || 0);
  const percents = submissions.filter((s) => s.status === "submitted").map((s) => Number(s.percent) || 0);
  const avgScore = scores.length ? (scores.reduce((a, b) => a + b, 0) / scores.length).toFixed(1) : "—";
  const avgPercent = percents.length ? (percents.reduce((a, b) => a + b, 0) / percents.length).toFixed(1) + "%" : "—";
  const elCount = document.getElementById("stat-count");
  const elAvgScore = document.getElementById("stat-avg-score");
  const elAvgPercent = document.getElementById("stat-avg-percent");
  const elSub = document.getElementById("stat-submitted");
  if (elCount) elCount.textContent = String(total);
  if (elAvgScore) elAvgScore.textContent = String(avgScore);
  if (elAvgPercent) elAvgPercent.textContent = String(avgPercent);
  if (elSub) elSub.textContent = String(submitted);
}

function renderTable() {
  const tbody = document.getElementById("tbody");
  if (!tbody) return;
  if (submissions.length === 0) {
    tbody.innerHTML = `<tr><td colspan="9" class="small muted" style="text-align:center;padding:24px">Әзірге қатысушы жоқ — сілтемені оқушыларға беріңіз</td></tr>`;
    return;
  }
  // Sort: submitted first, then by score desc
  const sorted = [...submissions].sort((a, b) => {
    if (a.status !== b.status) return a.status === "submitted" ? -1 : 1;
    return (Number(b.score) || 0) - (Number(a.score) || 0);
  });
  tbody.innerHTML = sorted
    .map((s, idx) => {
      const level = s.level || getLevel(Number(s.percent) || 0);
      const badgeClass = getLevelBadgeClass(level);
      const awaySec = s.totalAwayMs != null ? Math.round(Number(s.totalAwayMs) / 1000) : "—";
      const leaveCount = s.leaveCount != null ? String(s.leaveCount) : "—";
      const statusText = s.status === "submitted" ? "Жіберді" : "Орындауда";
      const scoreText = s.status === "submitted" ? String(s.score ?? "—") : "—";
      const percentText = s.status === "submitted" ? `${s.percent ?? 0}%` : "—";
      return `<tr>
        <td>${idx + 1}</td>
        <td style="font-weight:600">${esc(s.studentName || "—")}</td>
        <td>${esc(scoreText)}</td>
        <td>${esc(percentText)}</td>
        <td><span class="badge ${badgeClass}">${esc(level)}</span></td>
        <td>${esc(leaveCount)}</td>
        <td>${esc(String(awaySec))}</td>
        <td><span class="pill" style="font-size:11px">${esc(statusText)}</span></td>
        <td><button class="btn btn-ghost btn-small btn-detail" data-id="${esc(s.id)}" aria-label="Толығырақ">Толық</button></td>
      </tr>`;
    })
    .join("");
  tbody.querySelectorAll(".btn-detail").forEach((btn) => {
    btn.addEventListener("click", () => showSubmissionDetail(btn.dataset.id));
  });
}

function showSubmissionDetail(subId) {
  const s = submissions.find((x) => x.id === subId);
  if (!s) return;
  const qs = assessment.questions || [];
  let html = `<div style="text-align:left">`;
  html += `<p><b>${esc(s.studentName || "—")}</b> · ${esc(s.status === "submitted" ? "Жіберді" : "Орындауда")} · Шыққаны: ${esc(String(s.leaveCount ?? 0))} · Сыртта: ${Math.round(Number(s.totalAwayMs || 0)/1000)} сек</p>`;
  html += `<div style="margin-top:12px">`;
  for (let i = 0; i < qs.length; i++) {
    const q = qs[i];
    const ans = s.answers ? s.answers[q.id] : undefined;
    let ansText = ans == null || ans === "" ? "<i style='color:var(--subtle)'>Жауап жоқ</i>" : esc(String(ans));
    if (q.type === "single" && ans != null && ans !== "") {
      const opt = q.options ? q.options[Number(ans)] : undefined;
      ansText = esc(opt != null ? opt : String(ans));
    }
    html += `<div style="padding:10px 0;border-bottom:1px solid var(--border)">
      <div class="small muted">#${i + 1} · ${q.points} балл · ${q.type === "single" ? "Бір жауапты" : q.type === "short" ? "Қысқа" : "Ашық"}</div>
      <div style="font-weight:600;margin:4px 0">${esc(q.text)}</div>
      <div>Жауабы: ${ansText}</div>`;
    if (q.type === "single") html += `<div class="small muted">Дұрыс: ${esc(q.options ? q.options[Number(q.correct)] : String(q.correct))}</div>`;
    else if (q.type === "short") html += `<div class="small muted">Дұрыс: ${esc(String(q.correct))}</div>`;
    else html += `<div class="small muted">Ашық сұрақ — төменде бағалаңыз</div>`;
    html += `</div>`;
  }
  html += `</div></div>`;
  // Simple modal via toast container? Use alert-like modal
  const backdrop = document.createElement("div");
  backdrop.className = "modal-backdrop open";
  backdrop.innerHTML = `<div class="modal" role="dialog" aria-modal="true" style="max-width:640px"><h3>Оқушы жауабы</h3><div style="max-height:60vh;overflow:auto">${html}</div><div class="modal-actions"><button class="btn btn-secondary" data-close>Жабу</button></div></div>`;
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop || e.target.closest("[data-close]")) backdrop.remove();
  });
  document.body.appendChild(backdrop);
}

function renderHardQuestions() {
  const container = document.getElementById("hard-questions");
  if (!container) return;
  const qs = assessment.questions || [];
  const submitted = submissions.filter((s) => s.status === "submitted");
  if (submitted.length === 0 || qs.length === 0) {
    container.textContent = "Әзірге дерек жоқ — кемінде 1 оқушы жіберген соң есептеледі.";
    return;
  }
  // For each closed question, count incorrect
  const stats = qs
    .filter((q) => q.type !== "open")
    .map((q) => {
      let wrong = 0;
      let total = 0;
      for (const s of submitted) {
        const ans = s.answers ? s.answers[q.id] : undefined;
        if (ans == null || ans === "") {
          wrong += 1;
          total += 1;
          continue;
        }
        let correct = false;
        if (q.type === "single") correct = String(ans) === String(q.correct);
        else if (q.type === "short") correct = String(ans).trim().toLowerCase() === String(q.correct).trim().toLowerCase();
        if (!correct) wrong += 1;
        total += 1;
      }
      const rate = total ? (wrong / total) * 100 : 0;
      return { q, wrong, total, rate };
    })
    .sort((a, b) => b.rate - a.rate)
    .slice(0, 5);

  if (stats.length === 0) {
    container.textContent = "Ашық сұрақтар ғана — қателік статистикасы жоқ.";
    return;
  }
  container.innerHTML = stats
    .map((s, idx) => {
      return `<div style="display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px solid var(--border)">
        <span>#${assessment.questions.indexOf(s.q) + 1} ${esc(s.q.text.slice(0, 80))}${s.q.text.length > 80 ? "…" : ""}</span>
        <span style="white-space:nowrap;font-weight:700;color:${s.rate >= 50 ? "var(--danger)" : "var(--muted)"}">${s.wrong}/${s.total} · ${s.rate.toFixed(0)}% қате</span>
      </div>`;
    })
    .join("");
}

function renderOpenGrading() {
  const card = document.getElementById("open-grading-card");
  const container = document.getElementById("open-grading");
  if (!card || !container) return;
  const qs = assessment.questions || [];
  const openQs = qs.filter((q) => q.type === "open");
  if (openQs.length === 0) {
    card.classList.add("hidden");
    return;
  }
  card.classList.remove("hidden");
  // Show each submitted submission with open answers needing grading
  const submitted = submissions.filter((s) => s.status === "submitted");
  if (submitted.length === 0) {
    container.innerHTML = `<p class="small muted">Әзірге жіберген оқушы жоқ.</p>`;
    return;
  }
  // Check if any already graded: s.openScores is stored
  container.innerHTML = submitted
    .map((s) => {
      const openScores = s.openScores || {}; // { questionId: points }
      return `<div style="border:1px solid var(--border);border-radius:12px;padding:16px;margin-bottom:12px">
        <div style="font-weight:700">${esc(s.studentName || "—")} · ${s.score ?? 0} балл · ${s.percent ?? 0}%</div>
        ${openQs
          .map((q) => {
            const ans = s.answers ? s.answers[q.id] : "";
            const cur = openScores[q.id] != null ? String(openScores[q.id]) : "";
            return `<div style="margin-top:12px;padding:12px;background:var(--row-bg);border-radius:10px">
              <div class="small muted">#${qs.indexOf(q) + 1} · ${q.points} баллға дейін</div>
              <div style="font-weight:600;margin:4px 0">${esc(q.text)}</div>
              <div style="background:var(--card);border:1px solid var(--border);border-radius:8px;padding:10px;white-space:pre-wrap;min-height:40px">${ans ? esc(String(ans)) : "<span style='color:var(--subtle)'>Жауап жоқ</span>"}</div>
              <div class="flex gap8" style="margin-top:8px;align-items:center">
                <label class="small" style="font-weight:600">Балл:</label>
                <input type="number" class="input" style="max-width:100px;min-height:40px" min="0" max="${q.points}" value="${esc(cur)}" data-grade="${esc(s.id)}:${esc(q.id)}" placeholder="0–${q.points}" />
                <span class="small muted">/ ${q.points}</span>
              </div>
            </div>`;
          })
          .join("")}
        <button class="btn btn-primary btn-small mt16" data-save-open="${esc(s.id)}">Сақтау</button>
        <span class="small muted" data-status="${esc(s.id)}" style="margin-left:8px"></span>
      </div>`;
    })
    .join("");

  container.querySelectorAll("[data-save-open]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const subId = btn.dataset.saveOpen;
      const s = submissions.find((x) => x.id === subId);
      if (!s) return;
      const inputs = container.querySelectorAll(`[data-grade^="${CSS.escape(subId)}:"]`);
      // Fallback if CSS.escape not available
      const relevantInputs = Array.from(container.querySelectorAll("[data-grade]")).filter((el) => el.dataset.grade.startsWith(subId + ":"));
      const toScore = relevantInputs.length ? relevantInputs : inputs;
      const openScores = { ...(s.openScores || {}) };
      let changed = false;
      for (const inp of toScore) {
        const qid = inp.dataset.grade.split(":")[1];
        const q = openQs.find((x) => x.id === qid);
        if (!q) continue;
        const v = inp.value === "" ? null : Math.max(0, Math.min(Number(q.points), parseInt(inp.value, 10) || 0));
        if (v == null) delete openScores[qid];
        else {
          openScores[qid] = v;
          changed = true;
        }
      }
      const statusEl = container.querySelector(`[data-status="${CSS.escape(subId)}"]`) || container.querySelector(`[data-status="${subId}"]`);
      try {
        btn.disabled = true;
        btn.textContent = "Сақталуда...";
        // Recompute score: graded closed + openScores
        const qsAll = assessment.questions || [];
        // closed score
        // Use stored answers
        const grading = gradeAnswers(qsAll, s.answers || {});
        let openSum = 0;
        for (const q of openQs) {
          if (openScores[q.id] != null) openSum += Number(openScores[q.id]);
        }
        const totalScore = grading.score + openSum;
        const tp = assessment.totalPoints ?? totalPoints(qsAll);
        const percent = tp ? Math.round((totalScore / tp) * 100) : 0;
        const level = getLevel(percent);
        await updateDoc(doc(db, "assessments", assessmentId, "submissions", subId), {
          openScores,
          score: totalScore,
          percent,
          level,
        });
        if (statusEl) statusEl.textContent = "Сақталды ✓";
        showToast("Баға сақталды");
        setTimeout(() => { if (statusEl) statusEl.textContent = ""; }, 2000);
      } catch (e) {
        console.error(e);
        if (statusEl) statusEl.textContent = "Қате: " + (e.message || e.code);
        showToast("Сақтау қатесі: " + (e.message || e.code));
      } finally {
        btn.disabled = false;
        btn.textContent = "Сақтау";
      }
    });
  });
}

function renderEvents() {
  const el = document.getElementById("events-list");
  if (!el) return;
  if (events.length === 0) {
    el.textContent = "Әзірге оқиға жоқ";
    return;
  }
  const recent = [...events].slice(-20).reverse();
  el.innerHTML = recent
    .map((e) => {
      const time = e.at?.toDate ? e.at.toDate().toLocaleTimeString("kk-KZ", { hour: "2-digit", minute: "2-digit", second: "2-digit" }) : "—";
      const icon = e.type === "left" ? "⚠️" : "↩️";
      const text = e.type === "left" ? "сайттан шықты" : "қайтып келді";
      return `<div style="display:flex;justify-content:space-between;gap:12px;padding:6px 0;border-bottom:1px solid var(--border)">
        <span>${icon} <b>${esc(e.studentName || "—")}</b> ${esc(text)}</span>
        <span class="small muted">${esc(time)}</span>
      </div>`;
    })
    .join("");
}

// CSV download
document.getElementById("btn-csv")?.addEventListener("click", () => {
  if (submissions.length === 0) {
    showToast("Жүктейтін дерек жоқ");
    return;
  }
  const headers = ["Аты-жөні", "Балл", "Пайыз", "Деңгей", "Шыққаны", "Сыртта (сек)", "Күйі"];
  const rows = submissions.map((s) => {
    const level = s.level || getLevel(Number(s.percent) || 0);
    const awaySec = s.totalAwayMs != null ? Math.round(Number(s.totalAwayMs) / 1000) : "";
    return [
      s.studentName || "",
      s.score ?? "",
      s.percent != null ? String(s.percent) + "%" : "",
      level,
      s.leaveCount ?? "",
      awaySec,
      s.status === "submitted" ? "Жіберді" : "Орындауда",
    ];
  });
  // Pre-stats rows
  const tp = assessment.totalPoints ?? totalPoints(assessment.questions || []);
  const count = submissions.length;
  const subCount = submissions.filter((s) => s.status === "submitted").length;
  const avgScore = submissions.filter((s) => s.status === "submitted").reduce((a, s) => a + (Number(s.score) || 0), 0) / Math.max(1, subCount);
  const avgPercent = submissions.filter((s) => s.status === "submitted").reduce((a, s) => a + (Number(s.percent) || 0), 0) / Math.max(1, subCount);

  let csv = "";
  csv += `Тақырып,${csvEsc(assessment.topic || "")}\n`;
  csv += `Пән,${csvEsc(assessment.subject || "")}\n`;
  csv += `Түрі,${csvEsc(assessment.type || "")}\n`;
  csv += `Ең жоғары балл,${tp}\n`;
  csv += `Қатысты,${count}\n`;
  csv += `Жіберді,${subCount}\n`;
  csv += `Орташа балл,${avgScore.toFixed(1)}\n`;
  csv += `Орташа пайыз,${avgPercent.toFixed(1)}%\n`;
  csv += `\n`;
  csv += headers.map(csvEsc).join(",") + "\n";
  for (const r of rows) csv += r.map(csvEsc).join(",") + "\n";

  const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `natizhe-${assessmentId.slice(0, 8)}.csv`;
  a.click();
  URL.revokeObjectURL(url);
});

function csvEsc(v) {
  const s = String(v ?? "");
  if (s.includes(",") || s.includes('"') || s.includes("\n")) return `"${s.replace(/"/g, '""')}"`;
  return s;
}
